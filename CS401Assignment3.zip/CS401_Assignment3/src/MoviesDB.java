import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;

public class MoviesDB<T extends Comparable<T>> {

	private String fileName;
	private Map<String, RedBlackTree<String, HashSet<Integer>>> indexTreeMap = new HashMap<String, RedBlackTree<String, HashSet<Integer>>>();

	private Movie[] db;
	private int n = 0;

	public MoviesDB(String fileName) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(fileName));

		int i = 0;
		String str;
		String[] movieAttributes;
		Movie mov;
		while ((str = br.readLine()) != null) {
			n++;
		}
		br.close();
		n = n - 1;
		System.out.println(n);
		br = new BufferedReader(new FileReader(fileName));
		db = new Movie[n];
		while ((str = br.readLine()) != null && i < 50) {
			mov = new Movie();
			movieAttributes = str.split(",");
			if (i > 0) {

				mov.setId(Integer.parseInt(movieAttributes[0]));
				mov.setColor(movieAttributes[1]);
				mov.setMovie_title(movieAttributes[2]);
				mov.setDuration(movieAttributes[3]);
				mov.setDirector_name(movieAttributes[4]);
				mov.setActor_1_name(movieAttributes[5]);
				mov.setActor_2_name(movieAttributes[6]);
				mov.setActor_3_name(movieAttributes[7]);
				mov.setMovie_imdb_link(movieAttributes[8]);
				mov.setLanguage(movieAttributes[9]);
				mov.setCountry(movieAttributes[10]);
				mov.setContent_rating(movieAttributes[11]);
				mov.setTitle_year(movieAttributes[12]);
				mov.setImdb_score(movieAttributes[13]);
				db[i - 1] = mov;
			}

			i++;
		}

		br.close();

	}

	public void addFieldIndex(String field) {
		RedBlackTree<String, HashSet<Integer>> rbt = 
				new RedBlackTree<String, HashSet<Integer>>();
		HashSet<Integer> set;
	

		
		if(field == "getTitle_year") {
		for(int i = 0; i < 49;i++) {
			set = new HashSet<Integer>();
		
			
			if(!rbt.contains(db[i].getTitle_year())) {
				set.add(db[i].getId());
				rbt.put(db[i].getTitle_year(), set);
			}
			
			else {
				HashSet<Integer> insert = rbt.get(db[i].getTitle_year());
				insert.add(db[i].getId());
				rbt.put(db[i].getTitle_year(), insert);
			}
			
			
		}
		
		indexTreeMap.put(field, rbt);
		
		System.out.println(rbt.get("2010"));

	}
		

		if(field == "getImdb_score") {
		for(int i = 0; i < 49;i++) {
			set = new HashSet<Integer>();
		
			
			if(!rbt.contains(db[i].getImdb_score())) {
				set.add(db[i].getId());
				rbt.put(db[i].getImdb_score(), set);
			}
			
			else {
				HashSet<Integer> insert = rbt.get(db[i].getImdb_score());
				insert.add(db[i].getId());
				rbt.put(db[i].getImdb_score(), insert);
			}
			
			
		}
		indexTreeMap.put(field, rbt);
		
		System.out.println(rbt.get("9.9"));
		System.out.println(indexTreeMap);
	
	}
	}
	

}
