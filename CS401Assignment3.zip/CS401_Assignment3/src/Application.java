import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;

public class Application {

	public static void main(String[] args) throws IOException {
		
		
		HashSet<Integer> hash = new HashSet<Integer>();
		
		MoviesDB movieDB = new MoviesDB("movie_metadata.csv");
		movieDB.addFieldIndex("getTitle_year");
		movieDB.addFieldIndex("getImdb_score");

	}

}
